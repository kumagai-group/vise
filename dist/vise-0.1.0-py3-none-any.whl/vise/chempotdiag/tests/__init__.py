#  Copyright (c) Oba-group
#  Distributed under the terms of the MIT License.

__copyright__    = 'Akira Takahashi'
__version__ = "v1.0.0"
__author__       = 'Akira Takahashi'
__author_email__ = 'chempotdiag.gmail'
__url__          = 'http://github.com/account/repository'
